package com.incture.restaurant.service;

import com.incture.restaurant.dto.OrderStatus;
import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.entity.Order;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.MenuRepository;
import com.incture.restaurant.repository.OrderRepository;
import com.incture.restaurant.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.*;

@SpringBootTest
class OrderServiceTest {

    @InjectMocks
    private OrderService orderService;

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private MenuRepository menuRepository;

    private User user;
    private Order order;
    private MenuItem menuItem;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Setup test user
        user = new User();
        user.setId(3L);
        user.setUsername("Manu");

        // Setup test menu item
        menuItem = new MenuItem();
        menuItem.setId(4L);
        menuItem.setItemName("White Sauce Pasta");
        menuItem.setDescription("Tasty white sauce pasta with extra cheese");
        menuItem.setPrice(108.0);

        // Setup test order
        order = new Order();
        order.setId(1L);
        order.setUser(user);
        order.setMenuItems(Collections.singletonList(menuItem));
        order.setTotalPrice(108.0);
        order.setStatus(OrderStatus.PENDING);
    }

    @Test
    void testCreateOrder_Success() {
        // Mock repository methods
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        when(menuRepository.findAllById(anyList())).thenReturn(Collections.singletonList(menuItem));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        // Call service method
        Order createdOrder = orderService.createOrder(order);

        // Assertions
        assertNotNull(createdOrder);
        assertEquals(OrderStatus.PENDING, createdOrder.getStatus());
        assertEquals(108.0, createdOrder.getTotalPrice());
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void testCreateOrder_UserNotFound() {
        // Mock repository methods
        when(userRepository.findById(user.getId())).thenReturn(Optional.empty());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.createOrder(order));
        assertEquals("User not found", exception.getMessage());
    }

    @Test
    void testCreateOrder_MenuItemsNotFound() {
        // Mock repository methods
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        when(menuRepository.findAllById(anyList())).thenReturn(Collections.emptyList());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.createOrder(order));
        assertEquals("One or more menu items not found", exception.getMessage());
    }

    @Test
    void testCalculateTotalPrice_Success() {
        // Mock user retrieval
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        when(menuRepository.findAllById(anyList())).thenReturn(Collections.singletonList(menuItem));
        when(orderRepository.save(any(Order.class))).thenReturn(order);
        Order createdOrder = orderService.createOrder(order);
        assertNotNull(createdOrder); 
        assertEquals(108.0, createdOrder.getTotalPrice()); 
    }


    @Test
    void testUpdateOrder_Success() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.of(order));
        when(menuRepository.findAllById(anyList())).thenReturn(Collections.singletonList(menuItem));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        // Call service method
        Order updatedOrder = orderService.updateOrder(order.getId(), order);

        // Assertions
        assertEquals(108.0, updatedOrder.getTotalPrice());
        assertEquals(OrderStatus.PENDING, updatedOrder.getStatus());
        verify(orderRepository, times(1)).save(any(Order.class));
    }

    @Test
    void testUpdateOrder_OrderNotFound() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.empty());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.updateOrder(order.getId(), order));
        assertEquals("Order not found with ID: " + order.getId(), exception.getMessage());
    }

    @Test
    void testDeleteOrder_Success() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.of(order));
        doNothing().when(orderRepository).deleteById(order.getId());

        // Call service method
        assertDoesNotThrow(() -> orderService.deleteOrder(order.getId()));
        verify(orderRepository, times(1)).deleteById(order.getId());
    }

    @Test
    void testDeleteOrder_OrderNotFound() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.empty());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.deleteOrder(order.getId()));
        assertEquals("Order not found with ID: " + order.getId(), exception.getMessage());
    }

    @Test
    void testGetOrderStatus_Success() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.of(order));

        // Call service method
        OrderStatus status = orderService.getOrderStatus(order.getId());

        // Assertions
        assertEquals(OrderStatus.PENDING, status);
    }

    @Test
    void testGetOrderStatus_OrderNotFound() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.empty());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.getOrderStatus(order.getId()));
        assertEquals("Order not found with ID: " + order.getId(), exception.getMessage());
    }

    @Test
    void testUpdateOrderStatus_Success() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.of(order));
        when(orderRepository.save(any(Order.class))).thenReturn(order);

        // Call service method
        Order updatedOrder = orderService.updateOrderStatus(order.getId(), OrderStatus.COMPLETED);

        // Assertions
        assertEquals(OrderStatus.COMPLETED, updatedOrder.getStatus());
    }

    @Test
    void testUpdateOrderStatus_OrderNotFound() {
        // Mock repository methods
        when(orderRepository.findById(order.getId())).thenReturn(Optional.empty());

        // Call service method and assert exception
        RuntimeException exception = assertThrows(RuntimeException.class, () -> orderService.updateOrderStatus(order.getId(), OrderStatus.COMPLETED));
        assertEquals("Order not found with ID: " + order.getId(), exception.getMessage());
    }
}
