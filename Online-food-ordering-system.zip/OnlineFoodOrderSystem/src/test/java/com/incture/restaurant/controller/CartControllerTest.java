package com.incture.restaurant.controller;

import com.incture.restaurant.entity.Cart;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.service.CartService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CartControllerTest {

    @InjectMocks
    private CartController cartController;

    @Mock
    private CartService cartService;

    private User user;
    private Cart cart;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setId(1L);
        user.setUsername("testUser");

        cart = new Cart();
        cart.setId(1L);
        cart.setUser(user);
        cart.setTotalPrice(0.0);
    }

    @Test
    void testAddToCart_Success() {
        when(cartService.addToCart(1L, 1L, 2)).thenReturn(cart);

        ResponseEntity<Cart> response = cartController.addToCart(1L, 1L, 2);
        assertEquals(201, response.getStatusCodeValue());
        assertNotNull(response.getBody());
    }

    @Test
    void testAddToCart_Failure() {
        when(cartService.addToCart(1L, 1L, 2)).thenThrow(new RuntimeException("Invalid data"));

        ResponseEntity<Cart> response = cartController.addToCart(1L, 1L, 2);
        assertEquals(400, response.getStatusCodeValue());
        assertNull(response.getBody());
    }

    @Test
    void testGetCart_Success() {
        when(cartService.getCartByUserId(1L)).thenReturn(cart);

        ResponseEntity<Cart> response = cartController.getCart(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals(cart, response.getBody());
    }

    @Test
    void testGetCart_NotFound() {
        when(cartService.getCartByUserId(1L)).thenThrow(new RuntimeException("Cart not found"));

        ResponseEntity<Cart> response = cartController.getCart(1L);
        assertEquals(404, response.getStatusCodeValue());
        assertNull(response.getBody());
    }

    @Test
    void testClearCart_Success() {
        doNothing().when(cartService).clearCart(1L);

        ResponseEntity<String> response = cartController.clearCart(1L);
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Cart cleared successfully", response.getBody());
    }

    @Test
    void testClearCart_NotFound() {
        doThrow(new RuntimeException("Cart not found for user")).when(cartService).clearCart(1L);

        ResponseEntity<String> response = cartController.clearCart(1L);
        assertEquals(404, response.getStatusCodeValue());
        assertEquals("Cart not found for user", response.getBody());
    }
}
