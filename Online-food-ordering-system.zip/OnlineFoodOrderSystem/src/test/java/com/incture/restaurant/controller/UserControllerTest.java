package com.incture.restaurant.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.Optional;

@SpringBootTest
public class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private UserService userService;

    @InjectMocks
    private UserController userController;

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
        mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
    }

    // Test user registration success
    @Test
    public void testRegisterUser_Success() throws Exception {
        User user = new User("testuser", "password123");

        when(userService.registerUser(user)).thenReturn("User registered successfully");

        MvcResult result = mockMvc.perform(post("/api/users/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isCreated())
                .andExpect(content().string("User registered successfully"))
                .andReturn();

        verify(userService, times(1)).registerUser(user);
    }

    // Test user registration when username is already taken
    @Test
    public void testRegisterUser_UsernameTaken() throws Exception {
        User user = new User("existinguser", "password123");

        when(userService.registerUser(user)).thenReturn("Username is already taken");

        MvcResult result = mockMvc.perform(post("/api/users/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isConflict())
                .andExpect(content().string("Username is already taken"))
                .andReturn();

        verify(userService, times(1)).registerUser(user);
    }

    // Test login success
    @Test
    public void testLogin_Success() throws Exception {
        User user = new User("testuser", "password123");

        when(userService.login(user.getUsername(), user.getPassword())).thenReturn(Optional.of(user));

        mockMvc.perform(post("/api/users/login")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isOk())
                .andExpect(content().string("Login successful!"));

        verify(userService, times(1)).login(user.getUsername(), user.getPassword());
    }

    // Test login failure (wrong credentials)
    @Test
    public void testLogin_Failure() throws Exception {
        User user = new User("wronguser", "wrongpassword");

        when(userService.login(user.getUsername(), user.getPassword())).thenReturn(Optional.empty());

        mockMvc.perform(post("/api/users/login")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isUnauthorized())
                .andExpect(content().string("Login failed!"));

        verify(userService, times(1)).login(user.getUsername(), user.getPassword());
    }

    // Test validation error handling (invalid user data)
    @Test
    public void testRegisterUser_ValidationError() throws Exception {
        User user = new User("", ""); // Invalid username and password

        mockMvc.perform(post("/api/users/register")
                        .contentType("application/json")
                        .content(objectMapper.writeValueAsString(user)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.username").value("Username cannot be empty"))
                .andExpect(jsonPath("$.password").value("Password cannot be empty"));
    }
}
