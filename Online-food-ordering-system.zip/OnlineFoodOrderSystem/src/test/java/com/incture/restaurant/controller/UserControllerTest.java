package com.incture.restaurant.controller;

import com.incture.restaurant.entity.User;
import com.incture.restaurant.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setUsername("testUser");
        user.setPassword("password123");
    }

    @Test
    void testRegisterUser_UsernameTaken() {
        when(userService.registerUser(user)).thenReturn("Username is already taken");

        ResponseEntity<String> response = userController.registerUser(user);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("Username is already taken", response.getBody());
    }

    @Test
    void testRegisterUser_Success() {
        when(userService.registerUser(user)).thenReturn("User registered successfully");

        ResponseEntity<String> response = userController.registerUser(user);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("User registered successfully", response.getBody());
    }

    @Test
    void testLogin_Success() {
        when(userService.login(user.getUsername(), user.getPassword())).thenReturn(java.util.Optional.of(user));

        ResponseEntity<String> response = userController.login(user);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Login successful!", response.getBody());
    }

    @Test
    void testLogin_Failure() {
        when(userService.login(user.getUsername(), user.getPassword())).thenReturn(java.util.Optional.empty());

        ResponseEntity<String> response = userController.login(user);
        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
        assertEquals("Login failed!", response.getBody());
    }

    @Test
    void testLoginSuccess() {
        ResponseEntity<String> response = userController.loginSuccess();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Login successful!", response.getBody());
    }

    @Test
    void testLogoutSuccess() {
        ResponseEntity<String> response = userController.logoutSuccess();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Logout successful!", response.getBody());
    }
}
