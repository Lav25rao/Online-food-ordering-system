package com.incture.restaurant.controller;

import com.incture.restaurant.entity.Order;
import com.incture.restaurant.service.OrderService;
import com.incture.restaurant.ApiResponse;
import com.incture.restaurant.ErrorResponse;
import com.incture.restaurant.dto.OrderStatus;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


class OrderControllerTest {

    @InjectMocks
    private OrderController orderController;

    @Mock
    private OrderService orderService;

    private Order order;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        order = new Order();
        order.setId(1L);
        order.setTotalPrice(20.0);
        order.setStatus(OrderStatus.PENDING);
    }

    @Test
    void testCreateOrder_Success() {
        when(orderService.createOrder(order)).thenReturn(order);

        ResponseEntity<ApiResponse<Object>> response = orderController.createOrder(order);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Order created successfully", response.getBody().getMessage());
    }

    @Test
    void testCreateOrder_Failure() {
        when(orderService.createOrder(order)).thenThrow(new RuntimeException("User not found"));

        ResponseEntity<ApiResponse<Object>> response = orderController.createOrder(order);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertEquals("User not found", response.getBody().getMessage());
    }

    @Test
    void testUpdateOrder_Success() {
        when(orderService.updateOrder(order.getId(), order)).thenReturn(order);

        ResponseEntity<ApiResponse<Object>> response = orderController.updateOrder(order.getId(), order);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Order updated successfully", response.getBody().getMessage());
    }

    @Test
    void testDeleteOrder_Success() {
        doNothing().when(orderService).deleteOrder(order.getId());

        ResponseEntity<ApiResponse<Object>> response = orderController.deleteOrder(order.getId());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Order deleted successfully", response.getBody().getMessage());
    }

    @Test
    void testGetOrderStatus_Success() {
        when(orderService.getOrderStatus(order.getId())).thenReturn(OrderStatus.PENDING);

        ResponseEntity<ApiResponse<Object>> response = orderController.getOrderStatus(order.getId());
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(OrderStatus.PENDING, response.getBody().getData());
    }

    @Test
    void testUpdateOrderStatus_Success() {
        when(orderService.updateOrderStatus(order.getId(), OrderStatus.COMPLETED)).thenReturn(order);

        ResponseEntity<ApiResponse<Object>> response = orderController.updateOrderStatus(order.getId(), OrderStatus.COMPLETED);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Order status updated successfully", response.getBody().getMessage());
    }
}
