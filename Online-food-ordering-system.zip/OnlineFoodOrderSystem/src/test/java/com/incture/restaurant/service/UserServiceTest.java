package com.incture.restaurant.service;

import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.UserRepository;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class UserServiceTest {

    @InjectMocks
    private UserService userService;

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private MeterRegistry meterRegistry;

    @Mock
    private Counter loginCounter;

    private User user;

    @BeforeEach
    void setUp() {
        // Initialize mocks
        MockitoAnnotations.openMocks(this);

        // Ensure MeterRegistry is properly mocked
        when(meterRegistry.counter(anyString(), any(String[].class))).thenReturn(loginCounter);

        // Create a test user instance
        user = new User();
        user.setUsername("Manu");
        user.setPassword("manu111");
    }

    @Test
    void testRegisterUser_UserAlreadyExists() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.of(user));

        String response = userService.registerUser(user);
        assertEquals("Username is already taken", response);
        verify(userRepository, times(0)).save(user);
    }

    @Test
    void testRegisterUser_Success() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(user.getPassword())).thenReturn("encodedPassword");

        String response = userService.registerUser(user);
        assertEquals("User registered successfully", response);
        verify(userRepository, times(1)).save(user);
    }

    @Test
    void testLogin_Success() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(user.getPassword(), user.getPassword())).thenReturn(true);

        Optional<User> authenticatedUser = userService.login(user.getUsername(), user.getPassword());
        assertTrue(authenticatedUser.isPresent());
        verify(loginCounter, times(1)).increment();
    }

    @Test
    void testLogin_Failure() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.of(user));
        when(passwordEncoder.matches(user.getPassword(), "wrongPassword")).thenReturn(false);

        Optional<User> authenticatedUser = userService.login(user.getUsername(), "wrongPassword");
        assertFalse(authenticatedUser.isPresent());
        verify(loginCounter, times(0)).increment();
    }

    @Test
    void testLogin_UserNotFound() {
        when(userRepository.findByUsername(user.getUsername())).thenReturn(Optional.empty());

        Optional<User> authenticatedUser = userService.login(user.getUsername(), user.getPassword());
        assertFalse(authenticatedUser.isPresent());
    }
}
