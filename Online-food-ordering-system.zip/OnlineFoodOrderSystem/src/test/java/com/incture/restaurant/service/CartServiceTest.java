package com.incture.restaurant.service;

import com.incture.restaurant.entity.*;
import com.incture.restaurant.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import java.util.ArrayList;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CartServiceTest {

    @InjectMocks
    private CartService cartService;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private MenuRepository menuRepository;

    @Mock
    private UserRepository userRepository;

    private User user;
    private MenuItem menuItem;
    private Cart cart;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        user = new User();
        user.setId(1L);
        user.setUsername("testUser");

        menuItem = new MenuItem();
        menuItem.setId(1L);
        menuItem.setItemName("Pizza");
        menuItem.setPrice(100.0);

        cart = new Cart();
        cart.setId(1L);
        cart.setUser(user);
        cart.setTotalPrice(0.0);
    }

    @Test
    void testAddToCart_Success() {
        // Mock repository calls
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(menuRepository.findById(1L)).thenReturn(Optional.of(menuItem));
        when(cartRepository.findByUser(user)).thenReturn(Optional.of(cart));

        Cart updatedCart = cartService.addToCart(1L, 1L, 2);
        assertEquals(1, updatedCart.getCartItems().size());
        assertEquals(200.0, updatedCart.getTotalPrice());
    }

    @Test
    void testAddToCart_UserNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> cartService.addToCart(1L, 1L, 2));
        assertEquals("User not found", exception.getMessage());
    }

    @Test
    void testAddToCart_MenuItemNotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(menuRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> cartService.addToCart(1L, 1L, 2));
        assertEquals("Menu item not found", exception.getMessage());
    }

    @Test
    void testGetCartByUserId_Success() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(cartRepository.findByUser(user)).thenReturn(Optional.of(cart));

        Cart fetchedCart = cartService.getCartByUserId(1L);
        assertNotNull(fetchedCart);
        assertEquals(user.getId(), fetchedCart.getUser().getId());
    }

    @Test
    void testGetCartByUserId_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(cartRepository.findByUser(user)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> cartService.getCartByUserId(1L));
        assertEquals("Cart not found", exception.getMessage());
    }

    @Test
    void testClearCart_Success() {
        User user = new User();
        user.setId(1L);
        user.setUsername("testUser");

        Cart cart = new Cart();
        cart.setId(1L);
        cart.setUser(user);
        cart.setTotalPrice(100.0);
        cart.setCartItems(new ArrayList<>());
        when(userRepository.findById(1L)).thenReturn(Optional.of(user));
        when(cartRepository.findByUser(user)).thenReturn(Optional.of(cart));
        when(cartRepository.save(any(Cart.class))).thenReturn(cart);
        cartService.clearCart(1L);
        assertEquals(0.0, cart.getTotalPrice());
        assertTrue(cart.getCartItems().isEmpty());
    }



    @Test
    void testClearCart_NotFound() {
        when(userRepository.findById(1L)).thenReturn(Optional.empty());
        RuntimeException exception = assertThrows(RuntimeException.class, () -> {
            cartService.clearCart(1L);  // Try clearing the cart for a non-existent user
        });
        assertEquals("User not found", exception.getMessage());
    }

}
