package com.incture.restaurant.controller;

import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.service.MenuService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MenuControllerTest {

    @InjectMocks
    private MenuController menuController;

    @Mock
    private MenuService menuService;

    private MenuItem menuItem;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        menuItem = new MenuItem();
        menuItem.setId(1L);
        menuItem.setItemName("Burger");
        menuItem.setDescription("Delicious cheesy burger");
        menuItem.setPrice(150.0);
    }

    @Test
    void testAddMenuItem_Success() {
        when(menuService.addMenuItem(menuItem)).thenReturn(menuItem);

        ResponseEntity<MenuItem> response = menuController.addMenuItem(menuItem);
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals("Burger", response.getBody().getItemName());
    }

    @Test
    void testGetAllMenuItems() {
        when(menuService.getAllMenuItems()).thenReturn(Collections.singletonList(menuItem));

        ResponseEntity<List<MenuItem>> response = menuController.getAllMenuItems();
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(1, response.getBody().size());
    }

    @Test
    void testGetMenuItemById_Success() {
        when(menuService.getMenuItemById(1L)).thenReturn(menuItem);

        ResponseEntity<MenuItem> response = menuController.getMenuItemById(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Burger", response.getBody().getItemName());
    }

    @Test
    void testUpdateMenuItem_Success() {
        when(menuService.updateMenuItem(eq(1L), any(MenuItem.class))).thenReturn(menuItem);

        ResponseEntity<MenuItem> response = menuController.updateMenuItem(1L, menuItem);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Burger", response.getBody().getItemName());
    }

    @Test
    void testDeleteMenuItem_Success() {
        doNothing().when(menuService).deleteMenuItem(1L);

        ResponseEntity<String> response = menuController.deleteMenuItem(1L);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Menu item deleted successfully", response.getBody());
    }

    @Test
    void testDeleteMenuItem_NotFound() {
        doThrow(new RuntimeException("Menu item not found with ID: 1")).when(menuService).deleteMenuItem(1L);

        ResponseEntity<String> response = menuController.deleteMenuItem(1L);
        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertEquals("Menu item not found with ID: 1", response.getBody());
    }
}
