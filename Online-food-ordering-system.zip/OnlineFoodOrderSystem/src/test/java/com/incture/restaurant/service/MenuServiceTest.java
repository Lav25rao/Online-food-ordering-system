package com.incture.restaurant.service;

import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.repository.MenuRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class MenuServiceTest {

    @InjectMocks
    private MenuService menuService;

    @Mock
    private MenuRepository menuRepository;

    private MenuItem menuItem;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        menuItem = new MenuItem();
        menuItem.setId(1L);
        menuItem.setItemName("Burger");
        menuItem.setDescription("Cheesy burger with extra toppings");
        menuItem.setPrice(150.0);
    }

    @Test
    void testAddMenuItem_Success() {
        when(menuRepository.existsByItemName(menuItem.getItemName())).thenReturn(false);
        when(menuRepository.save(menuItem)).thenReturn(menuItem);

        MenuItem savedItem = menuService.addMenuItem(menuItem);
        assertNotNull(savedItem);
        assertEquals("Burger", savedItem.getItemName());
    }

    @Test
    void testAddMenuItem_ItemNameExists() {
        when(menuRepository.existsByItemName(menuItem.getItemName())).thenReturn(true);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> menuService.addMenuItem(menuItem));
        assertEquals("Menu item with this name already exists.", exception.getMessage());
    }

    @Test
    void testGetAllMenuItems() {
        when(menuRepository.findAll()).thenReturn(Collections.singletonList(menuItem));

        List<MenuItem> menuItems = menuService.getAllMenuItems();
        assertEquals(1, menuItems.size());
        assertEquals("Burger", menuItems.get(0).getItemName());
    }

    @Test
    void testGetMenuItemById_Success() {
        when(menuRepository.findById(menuItem.getId())).thenReturn(Optional.of(menuItem));

        MenuItem foundItem = menuService.getMenuItemById(1L);
        assertNotNull(foundItem);
        assertEquals("Burger", foundItem.getItemName());
    }

    @Test
    void testGetMenuItemById_NotFound() {
        when(menuRepository.findById(1L)).thenReturn(Optional.empty());

        RuntimeException exception = assertThrows(RuntimeException.class, () -> menuService.getMenuItemById(1L));
        assertEquals("Menu item not found", exception.getMessage());
    }

    @Test
    void testUpdateMenuItem_Success() {
        when(menuRepository.findById(1L)).thenReturn(Optional.of(menuItem));
        when(menuRepository.save(menuItem)).thenReturn(menuItem);

        MenuItem updatedItem = new MenuItem();
        updatedItem.setItemName("Veggie Burger");
        updatedItem.setDescription("Healthy veggie burger");
        updatedItem.setPrice(130.0);

        MenuItem result = menuService.updateMenuItem(1L, updatedItem);
        assertEquals("Veggie Burger", result.getItemName());
        assertEquals(130.0, result.getPrice());
    }

    @Test
    void testDeleteMenuItem_Success() {
        when(menuRepository.existsById(1L)).thenReturn(true);
        doNothing().when(menuRepository).deleteById(1L);

        assertDoesNotThrow(() -> menuService.deleteMenuItem(1L));
        verify(menuRepository, times(1)).deleteById(1L);
    }

    @Test
    void testDeleteMenuItem_NotFound() {
        when(menuRepository.existsById(1L)).thenReturn(false);

        RuntimeException exception = assertThrows(RuntimeException.class, () -> menuService.deleteMenuItem(1L));
        assertEquals("Menu item not found with ID: 1", exception.getMessage());
    }
}
