package com.incture.restaurant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;


@SpringBootApplication(scanBasePackages = "com.incture.restaurant")
@EnableJpaRepositories(basePackages = "com.incture.restaurant.repository")
@EntityScan(basePackages = "com.incture.restaurant.entity")
public class OnlineFoodOrderSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineFoodOrderSystemApplication.class, args);
	}

}
