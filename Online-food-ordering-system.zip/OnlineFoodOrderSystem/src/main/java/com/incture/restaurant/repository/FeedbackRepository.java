package com.incture.restaurant.repository;

import com.incture.restaurant.dto.FeedbackRequest;
import com.incture.restaurant.entity.Feedback;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FeedbackRepository extends JpaRepository<Feedback, Long> {

    // Find all feedback for a specific order
    List<Feedback> findByOrderId(Long orderId);

    // Find all feedback given by a specific user
    List<Feedback> findByUserId(Long userId);

	Feedback save(FeedbackRequest feedback);
}
