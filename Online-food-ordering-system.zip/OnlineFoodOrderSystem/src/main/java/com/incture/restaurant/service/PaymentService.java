package com.incture.restaurant.service;
import com.stripe.Stripe;
import com.stripe.model.PaymentIntent;

import jakarta.annotation.PostConstruct;

import com.stripe.exception.StripeException;
import java.util.HashMap;
import java.util.Map;

import com.incture.restaurant.entity.Payment;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.PaymentRepository;
import com.incture.restaurant.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private UserRepository userRepository;

    // Set your Stripe secret key here
    @PostConstruct
    public void init() {
        Stripe.apiKey = "sk_test_51QIuMPHBwRPXzVShC4vUQsZyQ2O9wDVPVx3C5GodTZpD12jX1IbNJqs3H4FfIp1UO4exMyk6tTX72SJaogMWjqUL00ovxPs1EN";
    }

    public Payment createPayment(Long userId, Double amount) throws StripeException {
        // Retrieve user details (if needed for any operations)
        User user = userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        // Create a payment intent with Stripe
        Map<String, Object> params = new HashMap<>();
        params.put("amount", (long) (amount * 100)); // Stripe expects amount in cents
        params.put("currency", "usd");

        PaymentIntent paymentIntent = PaymentIntent.create(params);

        // Create a Payment object and save to the database
        Payment payment = new Payment();
        payment.setAmount(amount);
        payment.setCurrency("usd");
        payment.setStatus(paymentIntent.getStatus());
        payment.setPaymentIntentId(paymentIntent.getId());
        payment.setUser(user);

        // Save payment to the database
        return paymentRepository.save(payment);
    }

    public Payment getPaymentByIntentId(String paymentIntentId) {
        return paymentRepository.findByPaymentIntentId(paymentIntentId)
                .orElseThrow(() -> new RuntimeException("Payment not found"));
    }
}

