package com.incture.restaurant.service;

import com.incture.restaurant.dto.FeedbackRequest;
import com.incture.restaurant.entity.Feedback;
import com.incture.restaurant.repository.FeedbackRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class FeedbackService {

    @Autowired
    private FeedbackRepository feedbackRepository;
    public Feedback submitFeedback(Long orderId, Long userId, int rating, String comment) {
        if (orderId == null) {
            throw new IllegalArgumentException("Order ID cannot be null");
        }

        FeedbackRequest feedback = new FeedbackRequest();
        feedback.setOrderId(orderId);
        feedback.setUserId(userId);
        feedback.setRating(rating);
        feedback.setComment(comment);

        // Save feedback to the database
        return feedbackRepository.save(feedback);
    }

    // Get feedback for a specific order
    public List<Feedback> getFeedbackForOrder(Long orderId) {
        return feedbackRepository.findByOrderId(orderId);
    }

    // Get feedback submitted by a specific user
    public List<Feedback> getFeedbackForUser(Long userId) {
        return feedbackRepository.findByUserId(userId);
    }
}
