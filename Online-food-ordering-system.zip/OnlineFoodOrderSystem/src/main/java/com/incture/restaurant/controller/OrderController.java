package com.incture.restaurant.controller;

import com.incture.restaurant.entity.Order;
import com.incture.restaurant.service.OrderService;
import com.incture.restaurant.ApiResponse;
import com.incture.restaurant.ErrorResponse;
import com.incture.restaurant.dto.OrderDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create a new order
    @PostMapping("/create")
    public ResponseEntity<ApiResponse<OrderDTO>> createOrder(@RequestBody Order order) {
        try {
            OrderDTO createdOrder = orderService.createOrder(order);
            ApiResponse<OrderDTO> response = new ApiResponse<>("Order created successfully", createdOrder);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Update an existing order
    @PutMapping("/update/{id}")
    public ResponseEntity<ApiResponse<OrderDTO>> updateOrder(@PathVariable Long id, @RequestBody Order order) {
        try {
            OrderDTO updatedOrder = orderService.updateOrder(id, order);
            ApiResponse<OrderDTO> response = new ApiResponse<>("Order updated successfully", updatedOrder);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Delete an order
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ApiResponse<String>> deleteOrder(@PathVariable Long id) {
        try {
            orderService.deleteOrder(id);
            ApiResponse<String> response = new ApiResponse<>("Order deleted successfully", "Order ID " + id);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<String> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (Exception e) {
            ApiResponse<String> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Update order status
    @PutMapping("/status/{id}")
    public ResponseEntity<ApiResponse<OrderDTO>> updateOrderStatus(@PathVariable Long id, @RequestBody String status) {
        try {
            OrderDTO updatedOrder = orderService.updateOrderStatus(id, status);
            ApiResponse<OrderDTO> response = new ApiResponse<>("Order status updated successfully", updatedOrder);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        } catch (Exception e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Get order status
    @GetMapping("/status/{id}")
    public ResponseEntity<ApiResponse<String>> getOrderStatus(@PathVariable Long id) {
        try {
            String status = orderService.getOrderStatus(id);
            ApiResponse<String> response = new ApiResponse<>("Order status fetched successfully", status);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<String> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        } catch (Exception e) {
            ApiResponse<String> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    @GetMapping("/all")
    public ResponseEntity<ApiResponse<List<OrderDTO>>> getAllOrders() {
        try {
            List<OrderDTO> orders = orderService.getAllOrders();
            ApiResponse<List<OrderDTO>> response = new ApiResponse<>("Orders fetched successfully", orders);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            ApiResponse<List<OrderDTO>> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }

    // Get order by ID
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<OrderDTO>> getOrderById(@PathVariable Long id) {
        try {
            Optional<OrderDTO> order = orderService.getOrderById(id);
            if (order.isPresent()) {
                ApiResponse<OrderDTO> response = new ApiResponse<>("Order fetched successfully", order.get());
                return ResponseEntity.ok(response);
            } else {
                ApiResponse<OrderDTO> response = new ApiResponse<>("Order not found", null);
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
            }
        } catch (Exception e) {
            ApiResponse<OrderDTO> response = new ApiResponse<>(e.getMessage(),null);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
        }
    }
}
