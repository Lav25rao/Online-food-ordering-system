package com.incture.restaurant.controller;

import com.incture.restaurant.entity.Order;
import com.incture.restaurant.service.OrderService;
import com.incture.restaurant.ApiResponse;
import com.incture.restaurant.ErrorResponse;
import com.incture.restaurant.dto.OrderStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
public class OrderController {

    @Autowired
    private OrderService orderService;

    // Create a new order
    @PostMapping("/create")
    public ResponseEntity<ApiResponse<Object>> createOrder(@RequestBody Order order) {
        try {
            Order createdOrder = orderService.createOrder(order);
            ApiResponse<Object> response = new ApiResponse<>("Order created successfully", createdOrder);
            return new ResponseEntity<>(response, HttpStatus.CREATED);
        } catch (RuntimeException e) {
            ApiResponse<Object> response = new ApiResponse<>(e.getMessage(), new ErrorResponse(e.getMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    // Update an order
    @PutMapping("/update/{id}")
    public ResponseEntity<ApiResponse<Object>> updateOrder(@PathVariable Long id, @RequestBody Order order) {
        try {
            Order updatedOrder = orderService.updateOrder(id, order);
            ApiResponse<Object> response = new ApiResponse<>("Order updated successfully", updatedOrder);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<Object> response = new ApiResponse<>(e.getMessage(), new ErrorResponse(e.getMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    // Delete an order
    @DeleteMapping("/delete/{id}")
    public ResponseEntity<ApiResponse<Object>> deleteOrder(@PathVariable Long id) {
        try {
            orderService.deleteOrder(id);
            ApiResponse<Object> response = new ApiResponse<>("Order deleted successfully", "Order ID " + id);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<Object> response = new ApiResponse<>(e.getMessage(), null);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    // Get order status
    @GetMapping("/status/{id}")
    public ResponseEntity<ApiResponse<Object>> getOrderStatus(@PathVariable Long id) {
        try {
            OrderStatus status = orderService.getOrderStatus(id);
            ApiResponse<Object> response = new ApiResponse<>("Order status fetched successfully", status);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<Object> response = new ApiResponse<>(e.getMessage(), new ErrorResponse(e.getMessage()));
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    // Update order status (PUT) - for admin or restaurant staff
    @PutMapping("/status/{id}")
    public ResponseEntity<ApiResponse<Object>> updateOrderStatus(@PathVariable Long id, @RequestBody OrderStatus status) {
        try {
            Order updatedOrder = orderService.updateOrderStatus(id, status);
            ApiResponse<Object> response = new ApiResponse<>("Order status updated successfully", updatedOrder);
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            ApiResponse<Object> response = new ApiResponse<>(e.getMessage(), new ErrorResponse(e.getMessage()));
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
}
