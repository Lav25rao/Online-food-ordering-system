package com.incture.restaurant.controller;

import com.incture.restaurant.dto.FeedbackRequest;
import com.incture.restaurant.entity.Feedback;
import com.incture.restaurant.repository.FeedbackRepository;
import com.incture.restaurant.service.FeedbackService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackService feedbackService;
    
    @Autowired
    private FeedbackRepository feedbackRepository;

    @PostMapping("/submit")
    public Feedback submitFeedback(@RequestBody FeedbackRequest feedbackRequest) {
        // Convert FeedbackRequest DTO to Feedback entity
        Feedback feedback = new Feedback();
        feedback.setOrderId(feedbackRequest.getOrderId());
        feedback.setUserId(feedbackRequest.getUserId());
        feedback.setRating(feedbackRequest.getRating());
        feedback.setComment(feedbackRequest.getComment());

        // Save feedback to the database
        return feedbackRepository.save(feedback);
    }

    // Endpoint to get feedback for a specific order
    @GetMapping("/order/{orderId}")
    public List<Feedback> getFeedbackForOrder(@PathVariable Long orderId) {
        return feedbackService.getFeedbackForOrder(orderId);
    }

    // Endpoint to get feedback submitted by a specific user
    @GetMapping("/user/{userId}")
    public List<Feedback> getFeedbackForUser(@PathVariable Long userId) {
        return feedbackService.getFeedbackForUser(userId);
    }
}

