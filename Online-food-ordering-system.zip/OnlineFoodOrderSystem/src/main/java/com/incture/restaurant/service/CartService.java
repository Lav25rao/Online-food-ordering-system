package com.incture.restaurant.service;

import com.incture.restaurant.entity.*;
import com.incture.restaurant.repository.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class CartService {

    @Autowired
    private CartRepository cartRepository;

    @Autowired
    private CartItemRepository cartItemRepository;

    @Autowired
    private MenuRepository menuRepository;

    @Autowired
    private UserRepository userRepository;

    public Cart addToCart(Long userId, Long menuItemId, Integer quantity) {
        // Fetch the user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Fetch the menu item
        MenuItem menuItem = menuRepository.findById(menuItemId)
                .orElseThrow(() -> new RuntimeException("Menu item not found"));

        // Fetch or create the cart for the user
        Cart cart = cartRepository.findByUser(user)
                .orElse(new Cart());
        
        // Initialize cartItems if it's null
        if (cart.getCartItems() == null) {
            cart.setCartItems(new ArrayList<>()); // Initialize the list
        }

        // Set the user for the cart
        cart.setUser(user);

        // Calculate the price for the quantity of the item
        double price = menuItem.getPrice() * quantity;

        // Create a new CartItem and set its properties
        CartItem cartItem = new CartItem();
        cartItem.setMenuItem(menuItem);
        cartItem.setCart(cart);
        cartItem.setQuantity(quantity);
        cartItem.setPrice(price);

        // Add the cartItem to the cart's items
        cart.getCartItems().add(cartItem);
        
        // Update the total price of the cart
        cart.setTotalPrice(cart.getTotalPrice() != null ? cart.getTotalPrice() + price : price);

        // Save the cart in the repository
        cartRepository.save(cart);

        return cart;
    }
 public Cart getCartByUserId(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return cartRepository.findByUser(user)
                .orElseThrow(() -> new RuntimeException("Cart not found"));
    }

    public void clearCart(Long userId) {
        Cart cart = getCartByUserId(userId);
        cart.getCartItems().clear();
        cart.setTotalPrice(0.0);
        cartRepository.save(cart);
    }
}
