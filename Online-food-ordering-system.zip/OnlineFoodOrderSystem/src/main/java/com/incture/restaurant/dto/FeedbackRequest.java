package com.incture.restaurant.dto;

import jakarta.validation.constraints.NotNull;

public class FeedbackRequest {
	
	    @NotNull(message = "Order ID cannot be null")
	    private Long orderId;
	    
	    @NotNull(message = "User ID cannot be null")
	    private Long userId;

	    private int rating;
	    private String comment;


	public Long getOrderId() {
		return orderId;
	}
	public Long getUserId() {
		return userId;
	}
	public Integer getRating() {
		return rating;
	}
	public String getComment() {
		return comment;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}

}
