package com.incture.restaurant.service;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.UserRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // Register a new user
    public String registerUser(User user) {
        if (userRepository.findByUsername(user.getUsername()).isPresent()) {
            logger.warn("Username '{}' is already taken.", user.getUsername());
            return "Username is already taken";
        }

        // Encrypt the password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        logger.info("User '{}' registered successfully.", user.getUsername());
        return "User registered successfully";
    }

    // Authenticate user login
    public Optional<User> login(String username, String password) {
        if (password == null || password.isEmpty()) {
            logger.error("Password is null or empty for user '{}'", username);
            return Optional.empty();
        }

        Optional<User> user = userRepository.findByUsername(username);

        if (user.isPresent() && passwordEncoder.matches(password, user.get().getPassword())) {
            logger.info("User '{}' logged in successfully.", username);
            return user;
        }

        logger.warn("Login failed for user '{}'.", username);
        return Optional.empty();
    }
}
