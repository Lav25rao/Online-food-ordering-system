package com.incture.restaurant;

public class PaymentRequest {
    private Double amount;

    // Getter and Setter
    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }
}
