package com.incture.restaurant.controller;

import com.incture.restaurant.entity.Cart;
import com.incture.restaurant.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;
    
    // Add item to cart
    @PostMapping("/add")
    public ResponseEntity<Cart> addToCart(
            @RequestParam Long userId,
            @RequestParam Long menuItemId,
            @RequestParam Integer quantity) {
        try {
            Cart cart = cartService.addToCart(userId, menuItemId, quantity);
            return ResponseEntity.status(201).body(cart); // 201 Created
        } catch (RuntimeException e) {
            return ResponseEntity.status(400).body(null); // Bad request for invalid data
        }
    }

    // Get cart by userId
    @GetMapping("/{userId}")
    public ResponseEntity<Cart> getCart(@PathVariable Long userId) {
        try {
            Cart cart = cartService.getCartByUserId(userId);
            return ResponseEntity.ok(cart);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(null); // Not found if cart doesn't exist
        }
    }

    // Clear the user's cart
    @PostMapping("/clear/{userId}")
    public ResponseEntity<String> clearCart(@PathVariable Long userId) {
        try {
            cartService.clearCart(userId);
            return ResponseEntity.ok("Cart cleared successfully");
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body("Cart not found for user"); // Not found if cart doesn't exist
        }
    }
}
