package com.incture.restaurant.controller;

import com.incture.restaurant.PaymentRequest;
import com.incture.restaurant.entity.Payment;
import com.incture.restaurant.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // Create payment using @RequestBody to accept JSON in the body
    @PostMapping("/create/{userId}")
    public ResponseEntity<Payment> createPayment(@PathVariable Long userId, @RequestBody PaymentRequest paymentRequest) {
        try {
            Payment payment = paymentService.createPayment(userId, paymentRequest.getAmount());
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }

    // Get payment status by paymentIntentId
    @GetMapping("/status/{paymentIntentId}")
    public ResponseEntity<Payment> getPaymentStatus(@PathVariable String paymentIntentId) {
        try {
            Payment payment = paymentService.getPaymentByIntentId(paymentIntentId);
            return ResponseEntity.ok(payment);
        } catch (Exception e) {
            return ResponseEntity.status(500).body(null);
        }
    }
}
