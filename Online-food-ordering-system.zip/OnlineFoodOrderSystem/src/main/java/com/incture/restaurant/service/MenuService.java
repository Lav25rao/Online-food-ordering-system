package com.incture.restaurant.service;

import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {

    @Autowired
    private MenuRepository menuRepository;

    public boolean isItemNameExists(String itemName) {
        return menuRepository.existsByItemName(itemName);
    }

    public MenuItem addMenuItem(MenuItem menu) {
        if (menuRepository.existsByItemName(menu.getItemName())) {
            throw new RuntimeException("Menu item with this name already exists.");
        }
        return menuRepository.save(menu);
    }

    public List<MenuItem> getAllMenuItems() {
        return menuRepository.findAll();
    }

    public MenuItem getMenuItemById(Long id) {
        return menuRepository.findById(id).orElseThrow(() -> new RuntimeException("Menu item not found"));
    }

    public MenuItem updateMenuItem(Long id, MenuItem updatedMenu) {
        MenuItem menu = getMenuItemById(id);
        menu.setItemName(updatedMenu.getItemName());
        menu.setDescription(updatedMenu.getDescription());
        menu.setPrice(updatedMenu.getPrice());
        return menuRepository.save(menu);
    }

    public void deleteMenuItem(Long id) {
        if (!menuRepository.existsById(id)) {
            throw new RuntimeException("Menu item not found with ID: " + id);
        }
        menuRepository.deleteById(id);
    }
}
