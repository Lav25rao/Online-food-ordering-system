package com.incture.restaurant.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.incture.restaurant.entity.User;
import com.incture.restaurant.service.UserService;

import jakarta.validation.Valid;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    // User Registration Endpoint
    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@Valid @RequestBody User user) {
        String response = userService.registerUser(user);

        if ("Username is already taken".equals(response)) {
            logger.warn("Registration attempt failed for user '{}'. Username is already taken.", user.getUsername());
            return ResponseEntity.badRequest().body(response);
        }

        logger.info("User '{}' registered successfully.", user.getUsername());
        return ResponseEntity.ok(response);
    }

    // User Login Endpoint
    @PostMapping("/login")
    public ResponseEntity<String> login(@Valid @RequestBody User user) {
        logger.debug("Attempting login for user '{}'", user.getUsername());

        Optional<User> authenticatedUser = userService.login(user.getUsername(), user.getPassword());

        if (authenticatedUser.isPresent()) {
            logger.info("User '{}' logged in successfully.", user.getUsername());
            return ResponseEntity.ok("Login successful!");
        }

        logger.warn("Login attempt failed for user '{}'.", user.getUsername());
        return ResponseEntity.status(401).body("Login failed!");
    }

    // Login Success Handler (if using session-based auth)
    @GetMapping("/login-success")
    public ResponseEntity<String> loginSuccess() {
        logger.info("Login successful!");
        return ResponseEntity.ok("Login successful!");
    }

    // Logout Success Handler
    @GetMapping("/logout-success")
    public ResponseEntity<String> logoutSuccess() {
        logger.info("Logout successful!");
        return ResponseEntity.ok("Logout successful!");
    }
}
