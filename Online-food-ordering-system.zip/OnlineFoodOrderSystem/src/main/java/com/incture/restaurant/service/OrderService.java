package com.incture.restaurant.service;

import com.incture.restaurant.dto.OrderDTO;
import com.incture.restaurant.dto.UserDTO;
import com.incture.restaurant.dto.MenuItemDTO;
import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.entity.Order;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.MenuRepository;
import com.incture.restaurant.repository.OrderRepository;
import com.incture.restaurant.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MenuRepository menuRepository;

    // Create a new order
    public OrderDTO createOrder(Order order) {
        // Validate user existence
        User user = userRepository.findById(order.getUser().getId())
                .orElseThrow(() -> new RuntimeException("User not found with ID: " + order.getUser().getId()));

        // Set user to order
        order.setUser(user);

        // Calculate total price
        double totalPrice = calculateTotalPrice(order.getMenuItems());
        order.setTotalPrice(totalPrice);
        order.setStatus("PENDING");  // Default status
        order.setOrderDate(new Date());

        // Save the order
        Order savedOrder = orderRepository.save(order);

        // Return the saved order as a DTO
        return mapOrderToDto(savedOrder);
    }

    // Helper method to calculate total price of an order
 // Helper method to calculate total price of an order
    private double calculateTotalPrice(List<MenuItem> menuItems) {
        if (menuItems == null || menuItems.isEmpty()) {
            throw new RuntimeException("Menu items cannot be empty");
        }

        // Fetch valid menu items and calculate the total price
        List<Long> itemIds = menuItems.stream().map(MenuItem::getId).collect(Collectors.toList());
        List<MenuItem> validMenuItems = menuRepository.findAllById(itemIds);

        // Check for missing menu items
        if (validMenuItems.size() != itemIds.size()) {
            throw new RuntimeException("One or more menu items not found");
        }

        // Check if the MenuItem data is correctly fetched
        validMenuItems.forEach(menuItem -> {
            if (menuItem.getItemName() == null || menuItem.getPrice() == null || menuItem.getDescription() == null) {
                throw new RuntimeException("Menu item is missing required fields");
            }
        });

        return validMenuItems.stream().mapToDouble(MenuItem::getPrice).sum();
    }


    // Get order by ID
    public Optional<OrderDTO> getOrderById(Long id) {
        return orderRepository.findById(id).map(this::mapOrderToDto);
    }

    // Update an existing order
    public OrderDTO updateOrder(Long id, Order updatedOrder) {
        Order existingOrder = orderRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + id));

        // Validate menu items
        List<Long> itemIds = updatedOrder.getMenuItems().stream()
                .map(MenuItem::getId)
                .collect(Collectors.toList());
        List<MenuItem> validMenuItems = menuRepository.findAllById(itemIds);

        if (validMenuItems.size() != itemIds.size()) {
            throw new RuntimeException("One or more menu items not found");
        }

        // Update order details
        existingOrder.setMenuItems(validMenuItems);
        existingOrder.setTotalPrice(calculateTotalPrice(validMenuItems));
        existingOrder.setStatus(updatedOrder.getStatus());

        Order savedOrder = orderRepository.save(existingOrder);
        return mapOrderToDto(savedOrder);
    }

    // Delete an order by ID
    public void deleteOrder(Long id) {
        if (!orderRepository.existsById(id)) {
            throw new RuntimeException("Order not found with ID: " + id);
        }
        orderRepository.deleteById(id);
    }

    // Update order status by ID
    public OrderDTO updateOrderStatus(Long orderId, String status) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));

        // Update status
        order.setStatus(status);
        Order savedOrder = orderRepository.save(order);
        return mapOrderToDto(savedOrder);
    }

    // Get order status by ID
    public String getOrderStatus(Long orderId) {
        return orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId))
                .getStatus();
    }

    // Convert Order entity to OrderDto
    private OrderDTO mapOrderToDto(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setTotalPrice(order.getTotalPrice());
        dto.setStatus(order.getStatus());
        dto.setOrderDate(order.getOrderDate());

        // Map User entity to UserDto
        UserDTO userDto = new UserDTO();
        userDto.setId(order.getUser().getId());
        userDto.setUsername(order.getUser().getUsername());
        dto.setUser(userDto);

        // Map MenuItem entities to MenuItemDto
        List<MenuItemDTO> menuItems = order.getMenuItems().stream().map(item -> {
            MenuItemDTO menuItemDTO = new MenuItemDTO();
            menuItemDTO.setId(item.getId());
            menuItemDTO.setItemName(item.getItemName());
            menuItemDTO.setPrice(item.getPrice());
            menuItemDTO.setDescription(item.getDescription());
            return menuItemDTO;
        }).collect(Collectors.toList());

        dto.setMenuItems(menuItems);
        return dto;
    }
    
 // Get all orders
    public List<OrderDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::mapOrderToDto)
                .collect(Collectors.toList());
    }


}
