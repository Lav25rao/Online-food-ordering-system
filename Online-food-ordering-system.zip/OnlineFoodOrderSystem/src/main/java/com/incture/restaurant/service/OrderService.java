package com.incture.restaurant.service;

import com.incture.restaurant.dto.OrderStatus;
import com.incture.restaurant.entity.MenuItem;
import com.incture.restaurant.entity.Order;
import com.incture.restaurant.entity.User;
import com.incture.restaurant.repository.MenuRepository;
import com.incture.restaurant.repository.OrderRepository;
import com.incture.restaurant.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;
    
    @Autowired 
    private UserRepository userRepository;

    @Autowired
    private MenuRepository menuRepository;

     
    // Create a new order
    public Order createOrder(Order order) {
        // Validate user existence
        User user = userRepository.findById(order.getUser().getId())
                 .orElseThrow(() -> new RuntimeException("User not found"));

        // Set user to order
        order.setUser(user);
        double totalPrice = calculateTotalPrice(order.getMenuItems());

        order.setTotalPrice(totalPrice);
        order.setStatus(OrderStatus.PENDING);  // Set default status as PENDING
        order.setOrderDate(new Date());  // Set current timestamp

        return orderRepository.save(order);
    }

    // Helper method to calculate total price of an order
    private double calculateTotalPrice(List<MenuItem> menuItems) {
        double totalPrice = 0.0;

        if (menuItems == null || menuItems.isEmpty()) {
            throw new RuntimeException("Menu items cannot be empty");
        }

        // Fetch all menu items and calculate total price
        List<Long> itemIds = menuItems.stream()
                                       .map(MenuItem::getId)
                                       .collect(Collectors.toList());

        List<MenuItem> validMenuItems = menuRepository.findAllById(itemIds);
        if (validMenuItems.size() != itemIds.size()) {
            throw new RuntimeException("One or more menu items not found");
        }

        // Calculate total price and validate item fields
        for (MenuItem item : validMenuItems) {
            if (item.getPrice() == null || item.getItemName() == null || item.getDescription() == null) {
                throw new RuntimeException("Menu item data is incomplete for item: " + item.getId());
            }
            totalPrice += item.getPrice();
        }

        return totalPrice;
    }

    // Get all orders
    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    // Get order by ID
    public Optional<Order> getOrderById(Long id) {
        return orderRepository.findById(id);
    }

    // Update an existing order
    public Order updateOrder(Long id, Order updatedOrder) {
        Optional<Order> existingOrderOptional = orderRepository.findById(id);
        if (existingOrderOptional.isPresent()) {
            Order existingOrder = existingOrderOptional.get();
            List<Long> itemIds = updatedOrder.getMenuItems().stream()
                                              .map(MenuItem::getId)
                                              .collect(Collectors.toList());

            List<MenuItem> validMenuItems = menuRepository.findAllById(itemIds);
            if (validMenuItems.size() != itemIds.size()) {
                throw new RuntimeException("One or more menu items not found");
            }

            existingOrder.setMenuItems(validMenuItems);

            // Validate menu item data
            validMenuItems.forEach(item -> {
                if (item.getItemName() == null || item.getPrice() == null || item.getDescription() == null) {
                    throw new RuntimeException("Menu item data is incomplete for item ID: " + item.getId());
                }
            });

            // Calculate new total price
            double totalPrice = validMenuItems.stream().mapToDouble(MenuItem::getPrice).sum();
            existingOrder.setTotalPrice(totalPrice);

            return orderRepository.save(existingOrder);
        } else {
            throw new RuntimeException("Order not found with ID: " + id);
        }
    }

    // Delete an order by ID
    public void deleteOrder(Long id) {
        Optional<Order> existingOrder = orderRepository.findById(id);
        if (existingOrder.isPresent()) {
            orderRepository.deleteById(id);
        } else {
            throw new RuntimeException("Order not found with ID: " + id);
        }
    }

    // Get order status by ID
    public OrderStatus getOrderStatus(Long orderId) {
        Optional<Order> order = orderRepository.findById(orderId);
        if (order.isPresent()) {
            return order.get().getStatus();
        } else {
            throw new RuntimeException("Order not found with ID: " + orderId);
        }
    }

    // Update order status by ID
    public Order updateOrderStatus(Long orderId, OrderStatus status) {
        Optional<Order> orderOptional = orderRepository.findById(orderId);
        if (orderOptional.isPresent()) {
            Order order = orderOptional.get();
            order.setStatus(status);  // Update order status
            return orderRepository.save(order);
        } else {
            throw new RuntimeException("Order not found with ID: " + orderId);
        }
    }
}
