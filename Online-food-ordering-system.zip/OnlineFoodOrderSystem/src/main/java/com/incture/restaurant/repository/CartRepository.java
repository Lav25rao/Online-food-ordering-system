package com.incture.restaurant.repository;

import com.incture.restaurant.entity.Cart;
import com.incture.restaurant.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CartRepository extends JpaRepository<Cart, Long> {
    Optional<Cart> findByUser(User user);
}
