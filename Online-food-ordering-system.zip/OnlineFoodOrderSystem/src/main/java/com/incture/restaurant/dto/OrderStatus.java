package com.incture.restaurant.dto;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum OrderStatus {
    PENDING, COMPLETED, CANCELLED;

	@JsonCreator
	public static OrderStatus fromString(String status) {
	    try {
	        return OrderStatus.valueOf(status.toUpperCase());
	    } catch (IllegalArgumentException e) {
	        throw new RuntimeException("Invalid order status: " + status);
	    }
	}

}

