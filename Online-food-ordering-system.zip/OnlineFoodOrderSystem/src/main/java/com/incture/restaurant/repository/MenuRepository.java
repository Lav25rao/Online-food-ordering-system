package com.incture.restaurant.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.incture.restaurant.entity.MenuItem;

public interface MenuRepository extends JpaRepository<MenuItem, Long> {

    boolean existsByItemName(String itemName);  // This method will now work as long as itemName exists in MenuItem
}
