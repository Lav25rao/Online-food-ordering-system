package com.incture.restaurant.dto;

import java.util.Date;
import java.util.List;

public class OrderDTO {
    private Long id;
    private Long userId;
    private List<MenuItemDTO> menuItems;
    private Double totalPrice;
    private String status;
    private Date orderDate;

    // Constructor
    public OrderDTO(Long id, Long userId, List<MenuItemDTO> menuItems, Double totalPrice, String status, java.util.Date date) {
        this.id = id;
        this.userId = userId;
        this.menuItems = menuItems;
        this.totalPrice = totalPrice;
        this.status = status;
        this.orderDate =  date;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public List<MenuItemDTO> getMenuItems() {
        return menuItems;
    }

    public void setMenuItems(List<MenuItemDTO> menuItems) {
        this.menuItems = menuItems;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(Double totalPrice) {
        this.totalPrice = totalPrice;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
}
