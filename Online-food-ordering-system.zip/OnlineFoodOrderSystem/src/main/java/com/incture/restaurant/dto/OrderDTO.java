package com.incture.restaurant.dto;



import java.util.Date;
import java.util.List;

import com.incture.restaurant.entity.Order;

public class OrderDTO {
	private Long id;
    private UserDTO user;
    private List<MenuItemDTO> menuItems;
    private Double totalPrice;
    private String status;
    private Date orderDate;
    private Order order;
	public Long getId() {
		return id;
	}
	public UserDTO getUser() {
		return user;
	}
	public List<MenuItemDTO> getMenuItems() {
		return menuItems;
	}
	public Double getTotalPrice() {
		return totalPrice;
	}
	public String getStatus() {
		return status;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public void setUser(UserDTO user) {
		this.user = user;
	}
	public void setMenuItems(List<MenuItemDTO> menuItems) {
		this.menuItems = menuItems;
	}
	public void setTotalPrice(Double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public OrderDTO(Long id, UserDTO user, List<MenuItemDTO> menuItems, Double totalPrice, String status,
			Date orderDate) {
		this.id = id;
		this.user = user;
		this.menuItems = menuItems;
		this.totalPrice = totalPrice;
		this.status = status;
		this.orderDate = orderDate;
	}
	public OrderDTO() {
	}
	public OrderDTO(Long orderId, String string, Order order) {
		id=orderId;
		status=string;
		this.setOrder(order);

	}
	public Order getOrder() {
		return order;
	}
	public void setOrder(Order order) {
		this.order = order;
	}


}
